﻿using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public int currentScore = 0;
    public int currentRound = 1;
    private int highscore = 0;

    public int pointsPerRoundGoal = 50;
    private int scoreAtRoundStart = 0;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI roundText;
    public TextMeshProUGUI highscoreText;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        highscore = PlayerPrefs.GetInt("Highscore", 0);
        scoreAtRoundStart = currentScore;
        UpdateUI();
    }

    public void AddScore(int points)
    {
        currentScore += points;

        if (currentScore > highscore)
        {
            highscore = currentScore;
            PlayerPrefs.SetInt("Highscore", highscore);
        }

        UpdateUI();
        CheckRoundProgress();
    }

    void CheckRoundProgress()
    {
        int pointsGainedThisRound = currentScore - scoreAtRoundStart;
        int requiredPoints = currentRound * pointsPerRoundGoal;

        if (pointsGainedThisRound >= requiredPoints)
        {
            NextRound();
        }
    }

    void NextRound()
    {
        currentRound++;
        scoreAtRoundStart = currentScore;
        UpdateUI();

        GameObject[] remainingZombies = GameObject.FindGameObjectsWithTag("Zombie");
        foreach (GameObject zombie in remainingZombies)
        {
            Destroy(zombie);
        }

        Bomb[] allBombs = FindObjectsByType<Bomb>(FindObjectsSortMode.None);
        foreach (Bomb bomb in allBombs)
        {
            bomb.ResetBomb();
        }

        PlayerShooting shooting = FindFirstObjectByType<PlayerShooting>();
        if (shooting != null)
        {
            shooting.UpgradeAndReload(3);
        }
    }

    void UpdateUI()
    {
        if (scoreText != null) scoreText.text = "Score: " + currentScore;
        if (roundText != null) roundText.text = "Round: " + currentRound;
        if (highscoreText != null) highscoreText.text = "Highscore: " + highscore;
    }
}