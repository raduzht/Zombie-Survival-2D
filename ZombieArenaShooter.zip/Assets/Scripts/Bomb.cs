using UnityEngine;

public class Bomb : MonoBehaviour
{
    public float explosionRadius = 3f;
    public GameObject explosionEffectPrefab;

    private bool hasExploded = false;
    private SpriteRenderer spriteRenderer;
    private Collider2D bombCollider;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        bombCollider = GetComponent<Collider2D>();
    }

    public void Explode()
    {
        if (hasExploded) return;
        hasExploded = true;

        GameObject[] zombies = GameObject.FindGameObjectsWithTag("Zombie");
        foreach (GameObject zombie in zombies)
        {
            if (zombie != null)
            {
                float distance = Vector2.Distance(transform.position, zombie.transform.position);
                if (distance <= explosionRadius)
                {
                    if (GameManager.Instance != null) GameManager.Instance.AddScore(10);
                    Destroy(zombie);
                }
            }
        }

        if (explosionEffectPrefab != null)
        {
            GameObject effect = Instantiate(explosionEffectPrefab, transform.position, Quaternion.identity);
            Destroy(effect, 0.5f);
        }

        if (spriteRenderer != null) spriteRenderer.enabled = false;
        if (bombCollider != null) bombCollider.enabled = false;
    }

    public void ResetBomb()
    {
        hasExploded = false;
        if (spriteRenderer != null) spriteRenderer.enabled = true;
        if (bombCollider != null) bombCollider.enabled = true;
    }
}