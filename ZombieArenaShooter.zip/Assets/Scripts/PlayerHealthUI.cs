using UnityEngine;

public class PlayerHealthUI : MonoBehaviour
{
    public GameObject[] hearts;

    public void UpdateHearts(int currentHealth)
    {
        for (int i = 0; i < hearts.Length; i++)
        {
            if (i >= currentHealth)
            {
                hearts[i].SetActive(false);
            }
        }
    }
}