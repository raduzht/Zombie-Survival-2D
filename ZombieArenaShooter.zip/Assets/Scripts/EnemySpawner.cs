using System;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject zombiePrefab;
    public float baseSpawnRate = 3f;
    private float nextSpawnTime = 0f;
    public float spawnDistance = 8f;

    void Update()
    {
        if (Time.time >= nextSpawnTime)
        {
            SpawnEnemy();
            nextSpawnTime = Time.time + GetCurrentSpawnRate();
        }
    }

    float GetCurrentSpawnRate()
    {
        if (GameManager.Instance != null)
        {
            float spawnInterval = (baseSpawnRate / 3f) / Mathf.Pow(2, GameManager.Instance.currentRound - 1);
            return Mathf.Max(spawnInterval, 0.1f);
        }
        return baseSpawnRate;
    }

    void SpawnEnemy()
    {
        GameObject player = GameObject.FindWithTag("Player");
        if (player == null) return;

        float randomAngle = UnityEngine.Random.Range(0f, 360f) * Mathf.Deg2Rad;
        Vector2 randomDirection = new Vector2(Mathf.Cos(randomAngle), Mathf.Sin(randomAngle));
        Vector3 spawnPosition = player.transform.position + (Vector3)(randomDirection * spawnDistance);

        GameObject newZombie = Instantiate(zombiePrefab, spawnPosition, Quaternion.identity);

        if (newZombie.GetComponent<ZombieAI>() == null)
        {
            newZombie.AddComponent<ZombieAI>();
        }
    }
}