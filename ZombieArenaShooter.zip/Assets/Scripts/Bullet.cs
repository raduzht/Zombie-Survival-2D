﻿using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float bulletSpeed = 9f;
    public float bulletLifetime = 2f;
    public float hitRadius = 0.4f;

    void Start()
    {
        Destroy(gameObject, bulletLifetime);
    }

    void Update()
    {
        transform.position += transform.up * bulletSpeed * Time.deltaTime;

        GameObject[] bombs = GameObject.FindGameObjectsWithTag("Bomb");
        foreach (GameObject bomb in bombs)
        {
            if (bomb != null)
            {
                float distance = Vector2.Distance(transform.position, bomb.transform.position);
                if (distance <= hitRadius)
                {
                    Bomb bScript = bomb.GetComponent<Bomb>();
                    if (bScript != null) bScript.Explode();
                    Destroy(gameObject);
                    return;
                }
            }
        }

        GameObject[] zombies = GameObject.FindGameObjectsWithTag("Zombie");
        foreach (GameObject zombie in zombies)
        {
            if (zombie != null)
            {
                float distance = Vector2.Distance(transform.position, zombie.transform.position);
                if (distance <= 1.2f)
                {
                    if (GameManager.Instance != null) GameManager.Instance.AddScore(10);
                    Destroy(zombie);
                    Destroy(gameObject);
                    break;
                }
            }
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Bomb"))
        {
            Bomb bScript = collision.gameObject.GetComponent<Bomb>();
            if (bScript != null) bScript.Explode();
            Destroy(gameObject);
        }
        else if (collision.gameObject.CompareTag("Zombie"))
        {
            if (GameManager.Instance != null) GameManager.Instance.AddScore(10);
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
    }
}